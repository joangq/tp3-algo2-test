#ifndef MINHEAP_H
#define MINHEAP_H

#include "heap.h"
#include "../puesto.h"

struct TupPuesto {
    Nat id;
    Puesto* puesto;

    TupPuesto(Nat id, Puesto* puesto);
};

class minHeap {
    public:
        minHeap(Nat n);

        void agregar(TupPuesto tup);

        Puesto* minimo() const;

        void removerMinimo();

    private:
        vector<TupPuesto> nodos;
        Nat tamActual;

        void hacerMinHeap(Nat i);

        void swap(Nat i, Nat j);
};


#endif //MINHEAP_H
