#include "minHeap.h"

TupPuesto::TupPuesto(Nat id, Puesto* puesto) {
    this->id = id;
    this->puesto = puesto;
}

minHeap::minHeap(Nat n) : tamActual(0) {
    this->nodos.reserve(n);
}

void minHeap::agregar(TupPuesto tup) {
    Nat i = tamActual;
    nodos[i] = tup;
    tamActual++;

    // Sift up.
    while (i != 0 && nodos[i].id < nodos[heap::Padre(i)].id) {
        Nat j = heap::Padre(i);
        swap(i, j);
        i = j;
    }
}

Puesto *minHeap::minimo() const {
    return nodos[0].puesto;
}

void minHeap::removerMinimo() {
    tamActual--;
    nodos[0] = nodos[tamActual];
    hacerMinHeap(0);
}

void minHeap::hacerMinHeap(Nat i) {
    Nat izq = heap::Izq(i);
    Nat der = heap::Der(i);
    Nat menor = i;

    if (izq < tamActual && nodos[izq].id < nodos[menor].id)
        menor = izq;

    if (der < tamActual && nodos[der].id < nodos[menor].id)
        menor = der;

    if (menor != i) {
        swap(i, menor);
        hacerMinHeap(menor);
    }
}

void minHeap::swap(Nat i, Nat j) {
    TupPuesto temp = nodos[i];
    nodos[i] = nodos[j];
    nodos[j] = temp;
}
