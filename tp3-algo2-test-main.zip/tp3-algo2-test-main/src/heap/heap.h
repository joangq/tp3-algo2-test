#ifndef HEAP_H
#define HEAP_H

#include "../tipos.h"
#include "maxHeap.h"
#include "minHeap.h"

namespace heap {
    const Nat Izq(Nat n);
    const Nat Der(Nat n);
    const Nat Padre(Nat n);
}

#endif //HEAP_H
