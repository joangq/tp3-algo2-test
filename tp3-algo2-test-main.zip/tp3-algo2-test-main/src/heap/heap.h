#ifndef HEAP_H
#define HEAP_H

#include "../tipos.h"
#include "../puesto.h"

namespace heap {
    const Nat Izq(Nat n);
    const Nat Der(Nat n);
    const Nat Padre(Nat n);

    class minHeap {
        public:
            struct TupPuesto {
                Nat id;
                Puesto* puesto;

                TupPuesto(Nat id, Puesto* puesto);
            };

            minHeap(Nat n);

            void agregar(TupPuesto tup);

            Puesto* minimo() const;

            void removerMinimo();

        private:
            vector<TupPuesto> nodos;
            Nat tamActual;

            void hacerMinHeap(Nat i);

            void swap(Nat i, Nat j);
    };

    class maxHeap {
        public:
            struct Nodo {
                Dinero gasto;
                Persona id;

                Nodo(Dinero gasto, Persona personaid);
            };

            maxHeap();
            maxHeap(Nat n, Nat maxid);

            void agregar(Nodo elem);

            Persona maximo() const;

            void removerMaximo();

            void modificarGasto(Persona persona, Dinero nuevoGasto);

        private:
            vector<Nodo> nodos;
            vector<Nat> indicesPersona;
            Nat tamActual;

            void hacerMaxHeap(Nat i);

            void swap(Nat i, Nat j);
    };
}

#endif //HEAP_H
