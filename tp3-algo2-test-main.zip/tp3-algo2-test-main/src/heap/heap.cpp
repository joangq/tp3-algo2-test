#include "heap.h"

const Nat heap::Izq(Nat n) {
    return 2*n + 1;
}

const Nat heap::Der(Nat n) {
    return 2*n + 2;
}

const Nat heap::Padre(Nat n) {
    return (n-1) / 2;
}
