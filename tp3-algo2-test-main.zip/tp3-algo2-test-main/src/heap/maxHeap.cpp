#include "maxHeap.h"

Nodo::Nodo(Dinero gasto, Persona personaid) {
    this->gasto = gasto;
    this->id = personaid;
}

maxHeap::maxHeap(Nat n, Nat maxid) : indicesPersona(maxid + 1), tamActual(0) {
    this->nodos.reserve(n);
}

void maxHeap::agregar(Nodo elem) {
    /* Creo una copia y le sumo 1 al id para poder representar a personas
       con id = 0. Ver TP2 para una aclaración más precisa. */
    Nodo copia_elem = elem;
    copia_elem.id += 1;

    Nat i = tamActual;
    nodos[i] = copia_elem;
    indicesPersona[elem.id] = i;

    tamActual++;

    Nat j;

    // Sift up.
    while (i != 0 and nodos[i].gasto > nodos[heap::Padre(i)].gasto) {
        j = heap::Padre(i);
        swap(i, j);
        i = j;
    }

    //Nat j = heap::Padre(i);

    // Sift up.
    while (i != 0 and nodos[i].gasto == nodos[j].gasto and nodos[i].id > nodos[j].id) {
        j = heap::Padre(i);
        swap(i, j);
        i = j;
    }
}

Persona maxHeap::maximo() const {
    // Le sumo 1 porque antes le había restado 1.
    return nodos[0].id + 1;
}

void maxHeap::removerMaximo() {
    nodos[tamActual] = Nodo(0, 0);
    tamActual--;
    nodos[0] = nodos[tamActual];
    hacerMaxHeap(0);
}

void maxHeap::modificarGasto(Persona persona, Dinero nuevoGasto) {
    Nat i = indicesPersona[persona];
    Dinero gasto = nodos[i].gasto;


    if (gasto < nuevoGasto) {
        nodos[i].gasto = nuevoGasto;
        hacerMaxHeap(i);
    } else if (gasto > nuevoGasto) {
        while (i != 0 && nodos[i].gasto > nodos[heap::Padre(i)].gasto) {
            Nat j = heap::Padre(i);
            swap(i, j);
            i = j;
        }
    }
}

void maxHeap::hacerMaxHeap(Nat i) {
    Nat izq = heap::Izq(i);
    Nat der = heap::Der(i);
    Nat mayor = i;

    if (izq < tamActual and nodos[izq].id > nodos[mayor].id) mayor = izq;

    if (der < tamActual and nodos[der].id > nodos[mayor].id) mayor = der;

    if (mayor != i) {
        swap(i, mayor);
        hacerMaxHeap(mayor);
    }
}

void maxHeap::swap(Nat i, Nat j) {
    // Primero, swappeo los indices en el diccionario de índices.
    // Les resto 1 porque las ids guardadas en nodos son 1 más que las reales.
    Nat tempIndice = nodos[i].id;
    indicesPersona[nodos[i].id - 1] = indicesPersona[nodos[j].id - 1];
    indicesPersona[nodos[j].id - 1] = tempIndice - 1;

    Nodo temp = nodos[i];
    nodos[i] = nodos[j];
    nodos[j] = temp;
}
