#ifndef MAX_HEAP_H
#define MAX_HEAP_H

#include "heap.h"
#include "../tipos.h"

struct Nodo {
    Dinero gasto;
    Persona id;

    Nodo(Dinero gasto, Persona personaid);
};

class maxHeap {
    public:
        maxHeap(Nat n, Nat maxid);

    void agregar(Nodo elem);

        Persona maximo() const;

        void removerMaximo();

        void modificarGasto(Persona persona, Dinero nuevoGasto);

    private:
        vector<Nodo> nodos;
        vector<Nat> indicesPersona;
        Nat tamActual;

        void hacerMaxHeap(Nat i);

        void swap(Nat i, Nat j);
};


#endif //MAX_HEAP_H
