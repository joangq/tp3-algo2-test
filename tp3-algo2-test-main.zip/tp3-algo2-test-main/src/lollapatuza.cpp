#include "lollapatuza.h"

using namespace std;

Lollapatuza::Lollapatuza(const diccLog<IdPuesto, Puesto>& puestos, const set<Persona>& personas)
                        : gastosPersonas(puestos.size(), idMaximo(personas)) {
    // Creo una lista que contenga todos los items, y la lleno.
    set<Producto> totalItems;

    // Itero sobre las tuplas de (IdPuesto, Puesto).
    for (auto const& tup : puestos) {
        // Utilizo referencias para evitar copiar la estructura.
        const Puesto& puesto = tup.second;
        const Stock& stock = puesto.obtenerStock();

        // Itero sobre las tuplas de (Producto, Cant).
        for (auto const& itemTup : stock) {
            Producto item = itemTup.first;
            // std::set no inserta el elemento si ya está en el conjunto.
            totalItems.emplace(item);
        }
    }

    map<Nat, heap::minHeap> dic;

    for (auto item : totalItems) {
        heap::minHeap heap(puestos.size());
        // Copia implícita.
        dic[item] = heap;
    }

    for (auto persona : personas) {
        gastosPersonas.agregar(heap::maxHeap::Nodo(0, persona));
        // En las siguientes asignaciones, la copia es implícita.
        infoCompras compras(0, dic);
        infoPersonas[persona] = compras;
    }

    this->puestos = puestos;
    this->gastosPersonas = gastosPersonas;
    this->infoPersonas = infoPersonas;
    this->personas = personas;
}

void Lollapatuza::registrarCompra(IdPuesto pid, Persona persona, Producto item, Cantidad cant) {
    // TODO
}

void Lollapatuza::hackear(Persona persona, Producto item) {
    // TODO
}


Dinero Lollapatuza::gastoTotalPersona(Persona persona) {
    // TODO
}


Persona Lollapatuza::personaMayorGasto() {
    // TODO
}

IdPuesto Lollapatuza::menorStock(Producto item) {
    // TODO
}


set<Persona> Lollapatuza::obtenerPersonas() {
    // TODO
}


diccLog<IdPuesto, Puesto> Lollapatuza::obtenerPuestos() {
    // TODO
}

// TODO
Lollapatuza::infoCompras::infoCompras(int i, map<Nat, heap::minHeap> map1) {

}
