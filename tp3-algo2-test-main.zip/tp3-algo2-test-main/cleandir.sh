rm *.a;
rm CMakeCache.txt;
rm Makefile;
rm cmake_install.cmake;
rm -r ./CMakeFiles
rm correrTests;
