./cleandir.sh;
cmake .;
make correrTests;
clear;
./correrTests;
