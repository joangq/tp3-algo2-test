#ifndef AUX_H
#define AUX_H

#include <vector>

using namespace std;

int busquedaBinaria(vector<int> A, int x, int low, int high);
vector<int> myMergeSort(vector<int> A);
vector<int> myMerge(vector<int> A);

#endif AUX_H