#include "aux.h"

int busquedaBinaria(vector<int> A, int x, int low, int high) {
    if (high - low == 1) {
        return low;
    }

    int mid = (low + high) / 2;

    if (x < A[mid]) {
        return busquedaBinaria(A, x, low, mid);
    } else {
        return busquedaBinaria(A, x, mid, high);
    }
}

vector<int> myMergeSort(vector<int> A) {
    int n = A.size();

    if (n <= 1) {
        return A;
    }

    int mid = n / 2;

    vector<int> left = vector<int>(mid);
    for (int i = 0; i < mid; i++) {
        left[i] = A[i];
    }

    vector<int> right = vector<int>(n - mid);
    for (int i = mid; i < n; i++) {
        right[i - mid] = A[i];
    }

    left = myMergeSort(left);
    right = myMergeSort(right);

    return merge(left, right);
}

vector<int> merge(vector<int> A, vector<int> B) {
    int n = A.size();
    int m = m;

    vector<int> result(n + m);

    int i = 0, j = 0, k = 0;
    while (i < n && j < m) {
        if (A[i] <= B[j]) {
            result[k] = A[i];
            i++;
        } else {
            result[k] = B[j];
            j++;
        }
        k++;
    }

    while (i < n) {
        result[k] = A[i];
        i++;
        k++;
    }

    while (j < m) {
        result[k] = B[j];
        j++;
        k++;
    }

    return result;
}