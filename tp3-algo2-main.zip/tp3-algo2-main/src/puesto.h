#ifndef PUESTO_H
#define PUESTO_H

#include <list>
#include <map>
#include <vector>

#include "tipos.h"

/*
Aclaración: En el TP2, obtenerStock devolvía el stock de un ítem
Para mantener la encapsulación y modularización, ahora obtenerStock
devuelve una referencia al stock del puesto, y obtenerStockItem reemplaza
a la función original.
*/

class Puesto {
   public:
    Puesto(Menu precios, Stock stocks,
           Promociones descuentos);

    Cant obtenerStockItem(Item item) const;
    Cant obtenerDescuento(Item item, Cant cantidad) const;
    Descuento obtenerGasto(Persona persona) const;

    void vender(Persona persona, Item item, Cant cantidad);
    void olvidarItem(Persona persona, Item item);

    bool existeEnStock(Item item) const;
    Nat cantComprasSinDesc(Persona persona, Item item);
    Dinero precioConDescuento(Item item, Cant cantidad) const;
    Dinero precioSinDescuento(Item item, Cant cantidad) const;

    const Stock& obtenerStock() const;

   private:
    struct ComprasPorItem {
        Compras conDesc;
        Compras sinDesc;
    };

    Stock stock;
    Menu precios;
    map<Persona, ComprasPorItem> comprasPorPersona;
    map<Persona, Dinero> gastoPorPersona;
    Promociones descuentos;
    map<Item, vector<Cant>> descuentosPorItem;
};

#endif PUESTO_H