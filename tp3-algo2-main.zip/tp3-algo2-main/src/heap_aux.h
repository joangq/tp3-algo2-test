int Izq(int n);
int Der(int n);
int Padre(int n);