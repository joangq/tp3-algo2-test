#ifndef MIN_HEAP_H
#define MIN_HEAP_H

#include <vector>

#include "heap_aux.h"
#include "puesto.h"
#include "tipos.h"

struct TupPuesto {
    Nat id;
    Puesto* puesto;

    TupPuesto(Nat id, Puesto* puesto) {
        this->id = id;
        this->puesto = puesto;
    }
};

class MinHeap {
   public:
    MinHeap(int n);

    void agregar(TupPuesto tup);
    Puesto* minimo() const;
    void removerMinimo();

   private:
    void hacerMinHeap(int i);
    void swap(int i, int j);

    vector<TupPuesto> nodos;
    Nat tamActual;
};

#endif MIN_HEAP_H