#include "aux.h"
#include "puesto.h"

Puesto::Puesto(Menu precios, Stock stocks,
           Promociones descuentos) {
    
    // Itero sobre las tuplas (Item, map<Nat, Nat>)
    for (auto& tup : descuentos) {
        Item item = tup.first;
        map<Nat, Nat>& dicc = tup.second;

        vector<Cant> temp(dicc.size());

        int k = 0;
        // Itero sobre las tuplas (Cant, Nat)
        for (auto& tup : dicc) {
            temp[k] = tup.first;
            ++k;
        }

        temp = myMergeSort(temp);

        // En esta asignación, la copia es implícita.
        descuentosPorItem[item] = temp;
    }

    this->stock = stocks;
    this->precios = precios;
    this->descuentos = descuentos;
}

Cant Puesto::obtenerStockItem(Item item) const {
    return stock.at(item);
}

Cant Puesto::obtenerDescuento(Item item, Cant cantidad) const {
    if (cantidad = 0 || descuentosPorItem.count(item) == 0) {
        return 0;
    } else {
        const vector<Cant>& cantidades = descuentosPorItem.at(item);

        if (cantidad < cantidades[0]) {
            return 0;
        } else {
            int i = busquedaBinaria(cantidades, cantidad, 0, cantidades.size());
            return cantidades[i];
        }
    }
}

Descuento Puesto::obtenerGasto(Persona persona) const {
    return gastoPorPersona.at(persona);
}

void Puesto::vender(Persona persona, Item item, Cant cantidad) {
    Cant stockItem = stock[item];
    Dinero gastoPersona = gastoPorPersona[persona];

    Dinero precioBase = precioSinDescuento(item, cantidad);
    Dinero precioFinal = precioConDescuento(item, cantidad);

    ComprasPorItem& comprasPersona = comprasPorPersona[persona];

    stock[item] = stockItem - cantidad;
    gastoPersona += precioFinal;

    Compras& diccCompras = comprasPersona.sinDesc;

    if (precioBase != precioFinal) {
        diccCompras = comprasPersona.conDesc;
    }
    diccCompras[item].push_front(cantidad);
}

void Puesto::olvidarItem(Persona persona, Item item) {
    ComprasPorItem& comprasPersonas = comprasPorPersona[persona];
    list<Cant>& comprasItem = comprasPersonas.sinDesc[item];
    int& compra = comprasItem.front();

    compra -= 1;

    if (compra == 0) {
        comprasItem.pop_front();
    }
}

bool Puesto::existeEnStock(Item item) const {
    return stock.count(item) == 1;
}

Nat Puesto::cantComprasSinDesc(Persona persona, Item item) {
    Compras& sinDesc = comprasPorPersona[persona].sinDesc;

    if (sinDesc.count(item) == 1) {
        return sinDesc[item].size();
    } else {
        return 0;
    }
}

Dinero Puesto::precioConDescuento(Item item, Cant cantidad) const {
    Descuento descuento = obtenerDescuento(item, cantidad);
    Dinero precioBase = precioSinDescuento(item, cantidad);

    return (precioBase - (precioBase/descuento));
}

Dinero Puesto::precioSinDescuento(Item item, Cant cantidad) const {
    return precios.at(item) * cantidad;
}

const Stock& Puesto::obtenerStock() const {
    return stock;
}