#include "lollapatuza.h"

Lollapatuza::Lollapatuza(const map<IdPuesto, Puesto>& puestos,
                         const set<Persona>& personas)
    : gastosPersonas(puestos.size(), idMaximo(personas)) {
    // Creo una lista que contenga todos los items, y la lleno.
    set<Item> totalItems;

    // Itero sobre las tuplas de (IdPuesto, Puesto).
    for (auto const& tup : puestos) {
        // Utilizo referencias para evitar copiar la estructura.
        const Puesto& puesto = tup.second;
        const Stock& stock = puesto.obtenerStock();

        // Itero sobre las tuplas de (Item, Cant).
        for (auto const& itemTup : stock) {
            Item item = itemTup.first;
            // std::set no inserta el elemento si ya está en el conjunto.
            totalItems.emplace(item);
        }
    }

    map<Nat, MinHeap> dic;

    for (auto item : totalItems) {
        MinHeap heap(puestos.size());
        // Copia implícita.
        dic[item] = heap;
    }

    for (auto persona : personas) {
        gastosPersonas.agregar(Nodo(0, persona));
        // En las siguientes asignaciones, la copia es implícita.
        InfoCompras infoCompras(0, dic);
        infoPersonas[persona] = infoCompras;
    }

    this->puestos = puestos;
    this->gastosPersonas = gastosPersonas;
    this->infoPersonas = infoPersonas;
    this->personas = personas;
}

void Lollapatuza::registrarCompra(IdPuesto pid, Persona persona, Item item,
                                  Cant cant) {
    Puesto puesto = puestos[pid];
    puesto.vender(persona, item, cant);

    InfoCompras& infoCompras = infoPersonas[persona];
    int precioConDescuento = puesto.precioConDescuento(item, cant);
    infoCompras.gastoTotal += precioConDescuento;

    if (precioConDescuento == puesto.precioSinDescuento(item, cant)) {
        if (puesto.cantComprasSinDesc(persona, item) == 0) {
            infoCompras.hackeables[item].agregar(TupPuesto(pid, &puesto));
        }
    }

    gastosPersonas.modificarGasto(persona, infoCompras.gastoTotal);
}

void Lollapatuza::hackear(Persona persona, Item item) {
    InfoCompras& infoCompras = infoPersonas[persona];
    MinHeap& hackeablesItem = infoCompras.hackeables[item];
    Puesto& puestoAHackear = *(hackeablesItem.minimo());

    Cant cantItem = puestoAHackear.cantComprasSinDesc(persona, item);
    if (cantItem == 1) {
        hackeablesItem.removerMinimo();
    }

    puestoAHackear.olvidarItem(persona, item);

    int precioItem = puestoAHackear.precioSinDescuento(item, 1);
    infoCompras.gastoTotal -= precioItem;

    gastosPersonas.modificarGasto(persona, infoCompras.gastoTotal);
}

Dinero Lollapatuza::gastoTotalPersona(Persona persona) const {
    return infoPersonas.at(persona).gastoTotal;
}

Persona Lollapatuza::personaMayorGasto() const {
    return gastosPersonas.maximo();
}

IdPuesto Lollapatuza::menorStock(Item item) const {
    // Utilizo INT32_MAX para que la comparación en el ciclo for
    // valga siempre la primera vez que ocurre.
    int32_t menorStock = INT32_MAX;
    int32_t menorId = INT32_MAX;
    Cant stockItem;

    // Itero sobre las tuplas (IdPuesto, Puesto)
    for (auto const& tup : puestos) {
        IdPuesto pid = tup.first;
        const Puesto& puesto = tup.second;

        if (puesto.existeEnStock(item)) {
            stockItem = puesto.obtenerStockItem(item);

            if (stockItem <= menorStock) {
                // Si son iguales, únicamente cambio el menorId si
                // el pid nuevo es menor al actual.
                if (stockItem == menorStock) {
                    if (pid < menorId)
                        menorId = pid;
                } else {
                    menorId = pid;
                }
                menorStock = stockItem;
            }
        }
    }

    return menorId;
}

const set<Persona>& Lollapatuza::obtenerPersonas() const {
    return personas;
}

const map<IdPuesto, Puesto> Lollapatuza::obtenerPuestos() const {
    return puestos;
}

Persona Lollapatuza::idMaximo(const set<Persona>& personas) {
    // Utilizo INT32_MIN para que la comparación en el ciclo for
    // valga siempre la primera vez que ocurre.
    int32_t idMax = INT32_MIN;

    for (auto const& persona : personas) {
        if (persona > idMax) {
            idMax = persona;
        }
    }

    return idMax;
}

// Funciones no presentes directamente en el TP2, pero utilizadas
// para el adecuado funcionamiento de fachada_lollapatuza.h
Nat Lollapatuza::stockEnPuesto(IdPuesto idPuesto, const Producto& producto) const {
    return puestos.at(idPuesto).obtenerStockItem(producto);
}

Nat Lollapatuza::descuentoEnPuesto(IdPuesto idPuesto, const Producto& producto, Nat cantidad) const {
    return puestos.at(idPuesto).obtenerDescuento(producto, cantidad);
}

Nat Lollapatuza::gastoEnPuesto(IdPuesto idPuesto, Persona persona) const {
    return puestos.at(idPuesto).obtenerGasto(persona);
}

set<IdPuesto> Lollapatuza::idsDePuestos() const {
    set<IdPuesto> ids;

    // Itero sobre las tuplas (IdPuesto, Puesto)
    for (auto const& tup : puestos) {
        ids.emplace(tup.first);
    }

    return ids;
}