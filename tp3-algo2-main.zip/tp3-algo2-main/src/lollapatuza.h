#ifndef LOLLAPATUZA_H
#define LOLLAPATUZA_H

#include <map>
#include <queue>
#include <set>

#include "max_heap.h"
#include "min_heap.h"
#include "puesto.h"
#include "tipos.h"

using namespace std;

class Lollapatuza {
   public:
    Lollapatuza(const map<IdPuesto, Puesto>& puestos,
                const set<Persona>& personas);

    void registrarCompra(IdPuesto pid, Persona persona, Item item, Cant cant);
    void hackear(Persona persona, Item item);

    Dinero gastoTotalPersona(Persona persona) const;
    Persona personaMayorGasto() const;
    IdPuesto menorStock(Item item) const;

    const set<Persona>& obtenerPersonas() const;
    const map<IdPuesto, Puesto> obtenerPuestos() const;

    // Funciones no presentes directamente en el TP2, pero utilizadas
    // para el adecuado funcionamiento de fachada_lollapatuza.h
    Nat stockEnPuesto(IdPuesto idPuesto, const Producto& producto) const;
    Nat descuentoEnPuesto(IdPuesto idPuesto, const Producto& producto,
                          Nat cantidad) const;
    Nat gastoEnPuesto(IdPuesto idPuesto, Persona persona) const;
    set<IdPuesto> idsDePuestos() const;

   private:
    Persona idMaximo(const set<Persona>& personas);

    struct InfoCompras {
        Dinero gastoTotal;
        map<Nat, MinHeap> hackeables;

        InfoCompras(Dinero gastoTotal, map<Nat, MinHeap> hackeables) {
            this->gastoTotal = gastoTotal;
            this-> hackeables = hackeables;
        }
    };

    map<int, Puesto> puestos;
    MaxHeap gastosPersonas;
    map<Persona, InfoCompras> infoPersonas;
    set<Persona> personas;
};

#endif LOLLAPATUZA_H