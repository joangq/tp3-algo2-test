#include "gtest-1.8.1/gtest.h"

class LollaTestPropios : public testing::Test {
protected:
    int test;

    void SetUp() {
        test = 1;
    }

};

TEST_F(LollaTestPropios, test) {
    EXPECT_EQ(1, 1);
}